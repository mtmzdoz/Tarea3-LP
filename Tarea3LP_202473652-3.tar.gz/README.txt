Nombre: Matilde Vásquez
Rol: 202473652-3
Versión Java: jkd-21.0.8

-Se inicia en Zona Arrecife
-Solo se puede avanzar/retroceder de zona con la Nave Exploradora 
-Para la Nave Estrellada, sin traje térmico solo se puede 1 acción antes de la derrota por sofocamiento, para "reiniciar" o 
no caer ante el calor, si se entra nuevamente a la Nave Exploradora y se sale, se puede volver a explorar/recolectar 
-Solo se puede nadar/mover dentro del rango de la zona 
-Solo se puede bajar de la Nave Exploradora en Zona Profunda si se cuenta con la mejora de traje termico y tanque
-Si se muere los items especiales se mantienen en el inventario y se revive en Nave Exploradora
-Solo se pueden crear objetos dentro de la nave y los objetos deben estar en el inventario del jugador
-Cuando se crean/mejoran objetos dentro de la nave, aparecen todas las opciones disponibles, si por ejemplo se hace la mejora de modulo
y luego se vuelve a ingresar para mejorar, sale que ya se hizo
-Robot solo se ocupa en el agua y se puede transferir lo que recolecto a la Nave Exploradora

me pueden perdonar esos 10 minutos de demora :( porfis 